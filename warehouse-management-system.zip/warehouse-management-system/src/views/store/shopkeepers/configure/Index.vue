<template>
    <div>
       仓库配置
    </div>
</template>

<script>
export default {
    
}
</script>