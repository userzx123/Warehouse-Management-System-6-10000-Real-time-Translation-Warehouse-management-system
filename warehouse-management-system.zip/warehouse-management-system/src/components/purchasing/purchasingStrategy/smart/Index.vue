<template>
    <div>
        智能补货
    </div>
</template>

<script>
export default {
    
}
</script>