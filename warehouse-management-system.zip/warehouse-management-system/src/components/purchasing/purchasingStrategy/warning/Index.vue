<template>
    <div>
        库存预警补货
    </div>
</template>

<script>
export default {
    
}
</script>